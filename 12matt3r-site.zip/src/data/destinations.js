// The 12matt3r roster + store + labs, cast as characters and structures at a
// night festival. Each destination is someone (or somewhere) you walk up to.
// `model` selects the procedural build; `accent` drives aura + label colour;
// `url` is the real place the CTA opens; `rot` overrides facing when needed.

export const PALETTE = {
  cyan: '#00F3FF',
  magenta: '#FF0055',
  green: '#39FF14',
  purple: '#b967ff',
  orange: '#ff6b35',
  gold: '#e6c04a',
  ink: '#e6e6f0',
  bg: '#05050e',
};

export const DESTINATIONS = [
  {
    id: 'ravecharles', name: 'RAVE CHARLES', model: 'raver',
    role: 'headliner // masked on the main stage', accent: PALETTE.magenta,
    pos: [0, 0, -22], onStage: true, tag: 'rapper · DJ · founder',
    url: 'https://express.adobe.com/page/s43NCJty7DfTO/',
    blurb: 'The masked headliner running the decks behind a glowing LED visor — nearly 400 shows across America, 2014–2020. Reach the front and his live-history timeline opens.',
    cta: 'Open the tour timeline',
  },
  {
    id: 'shmorez', name: 'SHMOREZ', model: 'marshmallow',
    role: 'in the pit // front-left', accent: PALETTE.orange,
    pos: [-8, 0, -6], tag: 'dubstep · weird bass',
    url: 'https://shmorez-official-epk--sofakingsadboi.on.websim.com/',
    blurb: 'A toasted marshmallow man squishing to the bass in the pit — an animated electronic marshmallow squish of fire. His EPK (custom player, press assets, the drops) opens when you reach him.',
    cta: 'Enter SHMOREZ EPK',
  },
  {
    id: 'driftwave', name: 'DRIFTWAVE STATIC', model: 'vaporwave',
    role: 'chill zone // left', accent: PALETTE.purple,
    pos: [-14, 0, 2], tag: 'ambient · vaporwave',
    url: 'https://staticcorp--sofakingsadboi.on.websim.com/',
    blurb: 'A chrome vaporwave figure in shades, haloed by a retro striped sun, holding down the slushwave chill zone. The calm counterweight to the main stage.',
    cta: 'Enter DriftWave EPK',
  },
  {
    id: 'tanky', name: 'TANKY JOHNSON', model: 'cowboy',
    role: 'crowd // right', accent: PALETTE.gold,
    pos: [11, 0, -4], tag: 'outlaw country',
    url: 'https://tanky-johnson-epk--sofakingsadboi.on.websim.com/',
    blurb: 'The outlaw of the void — a cowboy in a brown hat, white tee and blue jeans, holding the right flank. Gold-on-black EPK: bio, latest tracks, and a booking desk.',
    cta: 'Enter Tanky EPK',
  },
  {
    id: 'studio', name: '12MATT3R', model: 'glitch',
    role: 'the VJ booth // visuals', accent: PALETTE.cyan,
    pos: [7, 0, 8], tag: 'glitch art · code · the collective',
    url: 'https://12matt3r.univer.se/',
    blurb: 'A glitching, RGB-splitting figure at the VJ booth driving every screen at the festival — the web-OS and glitch-art engine that houses all of this. The studio itself.',
    cta: 'Open the web-OS',
  },
  {
    id: 'store', name: 'THE MERCH TENT', model: 'stall',
    role: 'the vendor // commissions', accent: PALETTE.green,
    pos: [-6, 0, 12], tag: 'high-ticket commissions',
    url: 'https://www.etsy.com/shop/12matt3r',
    blurb: 'The vendor working the merch tent. Productized packages — visual identity, audio branding, a web-OS build like this one — with pricing, a tip jar, and an intake + NDA flow. Where the experience converts.',
    cta: 'Browse commissions',
  },
  {
    id: 'labs', name: 'THE LAB', model: 'labsstage',
    role: 'the side stage // experiments', accent: PALETTE.green,
    pos: [18, 0, 4], rot: -1.79, tag: 'trippy cam · dreamOS tv · deadnet',
    url: 'https://12matt3r.univer.se/',
    blurb: 'The Lab gets its own side stage: three live screens running the experiments — Trippy Cam (a browser feedback loop), DreamOS TV (a glitching virtual CRT), and Deadnet (alternative web protocols). The weird tools that prove what you can build.',
    cta: 'Enter the Lab',
  },
];
